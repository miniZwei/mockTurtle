$(document).ready(function () {
    $(".owl-carousel").owlCarousel();


    owl.owlCarousel({
        items: 4,                 // 한번에 보여줄 아이템 수
        loop: true,               // 반복여부
        margin: 10              // 오른쪽 간격

    });
});


function modalTw(modalname){
    document.get
$("#modalTw").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbTw").click(function(){
$("#modalTw").fadeOut();
});
}

function modalRv(modalname){
    document.get
$("#modalRv").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbRv").click(function(){
$("#modalRv").fadeOut();
});
}

function modalHm(modalname){
    document.get
$("#modalHm").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbHm").click(function(){
$("#modalHm").fadeOut();
});
}

function modalSf(modalname){
    document.get
$("#modalSf").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbSf").click(function(){
$("#modalSf").fadeOut();
});
}

function modalCr(modalname){
    document.get
$("#modalCr").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbCr").click(function(){
$("#modalCr").fadeOut();
});
}

function modalUn(modalname){
    document.get
$("#modalUn").fadeIn(300);
$("."+modalname).fadeIn(300);

$("#mbUn").click(function(){
$("#modalUn").fadeOut();
});
}

function modalLog(modalname){
    document.get
$("#modalLog").fadeIn(300);
$("."+modalname).fadeIn(300);

$('#modalLog').click(function(){
    $('#modalLog').fadeOut();
});
}

function hint1(modalname){
    document.get
$("#hint1").fadeIn(300);
$("."+modalname).fadeIn(300);
}

function hint2(modalname){
    document.get
$("#hint2").fadeIn(300);
$("."+modalname).fadeIn(300);
}

function hint3(modalname){
    document.get
$("#hint3").fadeIn(300);
$("."+modalname).fadeIn(300);
}

function hint4(modalname){
    document.get
$("#hint4").fadeIn(300);
$("."+modalname).fadeIn(300);
}

function solution(modalname){
    document.get
$("#answer").fadeIn(300);
$("."+modalname).fadeIn(300);
}

